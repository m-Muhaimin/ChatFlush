# AI Chat Assistant

## Overview

This is a Flask-based AI chat application that provides a conversational interface powered by Deepseek's AI model with OpenAI API compatibility. The application features a modern, full-width BeeBot-inspired web interface with complete authentication system, dark/light theme switching, and liquid background animations. Users can interact with an AI assistant through multiple conversation modes (Chat, Reasoning, Image Creation, Deep Research) with real-time streaming, file upload support, and personalized user profiles. The architecture is modular with secure session management, PostgreSQL database storage, and comprehensive error handling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built with vanilla JavaScript, HTML, and CSS with embedded styles for optimal performance
- **UI Framework**: Bootstrap 5 for responsive design and component styling
- **Design System**: BeeBot-inspired full-width interface with liquid background animations, glass morphism effects, and smaller refined components
- **Theme System**: Complete dark/light theme support with CSS variables, smooth transitions, and user preference storage
- **Real-time Communication**: AJAX-based messaging system with improved streaming, typing indicators, and auto-resizing input
- **Component Structure**: Modern JavaScript class-based architecture with authentication integration, theme management, and multimodal support
- **Visual Effects**: Liquid blob animations, glass blur effects, hover transitions, and smooth component interactions

### Backend Architecture
- **Web Framework**: Flask with CORS, Flask-Login for authentication, and Flask-SQLAlchemy for database management
- **Authentication System**: Complete user registration/login with secure password hashing, session management, and profile storage
- **Database Layer**: PostgreSQL with SQLAlchemy ORM, user models, chat sessions, and message history storage
- **Service Layer Pattern**: Dedicated `ChatService` class handles all AI interactions with mode-specific system prompts
- **API Design**: RESTful JSON API with authentication endpoints (`/api/login`, `/api/register`, `/api/logout`), user management (`/api/user`, `/api/user/theme`), and chat processing (`/api/chat`)
- **Security Features**: Password hashing with Werkzeug, session-based authentication, login requirements, and CSRF protection
- **Error Handling**: Comprehensive error handling with user-friendly messages and database transaction rollbacks

### AI Integration
- **Primary AI Provider**: Deepseek AI model integration via OpenAI-compatible API
- **Fallback Strategy**: Graceful degradation with mock responses when API is unavailable
- **Multimodal Support**: File attachment handling, image recognition preparation, and mode-specific system prompts
- **Conversation Modes**: Standard chat, step-by-step reasoning, image creation assistance, and comprehensive research modes
- **Response Configuration**: Adaptive temperature and token limits based on conversation mode (0.3 for reasoning, 0.7 for general chat)

### Security & Configuration
- **Authentication**: Complete user registration and login system with Flask-Login integration
- **Password Security**: Secure password hashing with Werkzeug's generate_password_hash/check_password_hash
- **Session Management**: Flask session handling with PostgreSQL-backed user sessions and "remember me" functionality
- **API Key Management**: Secure environment variable storage for Deepseek API credentials and database connection
- **Database Security**: PostgreSQL with proper foreign key constraints, transaction handling, and data validation
- **Input Validation**: Server-side validation for authentication forms, message content, and file uploads
- **Route Protection**: Login-required decorators protecting chat and user management endpoints

## External Dependencies

### AI Services
- **OpenAI API**: Primary AI service provider using GPT-4o model for natural language processing and response generation

### Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive design and UI components
- **Font Awesome 6**: Icon library for user interface elements
- **Google Fonts (Inter)**: Modern typography system for enhanced readability

### Python Packages
- **Flask**: Core web framework for application structure and routing
- **Flask-CORS**: Cross-origin resource sharing support for API endpoints
- **OpenAI Python Client**: Official SDK for OpenAI API integration

### Development Infrastructure
- **Environment Variables**: Configuration management for API keys and application secrets
- **Logging**: Built-in Python logging for debugging and monitoring
- **Static Asset Serving**: Flask's built-in static file serving for CSS, JavaScript, and other assets