import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from chat_service import ChatService

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Database configuration
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    'pool_pre_ping': True,
    "pool_recycle": 300,
}

# Initialize extensions
db = SQLAlchemy(app, model_class=Base)
CORS(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth_page'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Create database tables
with app.app_context():
    from models import User, ChatSession, ChatMessage
    db.create_all()

# Initialize chat service
chat_service = ChatService()

# Routes
@app.route('/')
def index():
    """Main chat interface - requires login"""
    if current_user.is_authenticated:
        return render_template('index.html')
    else:
        return redirect(url_for('auth_page'))

@app.route('/auth')
def auth_page():
    """Authentication page for login/signup"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('auth.html')

@app.route('/api/login', methods=['POST'])
def login():
    """Handle user login"""
    try:
        from models import User
        data = request.get_json()
        
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({
                'error': 'Username and password are required',
                'status': 'error'
            }), 400
        
        user = User.query.filter(
            (User.username == username) | (User.email == username)
        ).first()
        
        if user and user.check_password(password):
            login_user(user, remember=True)
            return jsonify({
                'success': True,
                'message': 'Login successful',
                'user': user.to_dict()
            })
        else:
            return jsonify({
                'error': 'Invalid username or password',
                'status': 'error'
            }), 401
            
    except Exception as e:
        app.logger.error(f"Login error: {str(e)}")
        return jsonify({
            'error': 'An error occurred during login',
            'status': 'error'
        }), 500

@app.route('/api/register', methods=['POST'])
def register():
    """Handle user registration"""
    try:
        from models import User
        data = request.get_json()
        
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        first_name = data.get('first_name', '').strip()
        last_name = data.get('last_name', '').strip()
        
        if not all([username, email, password]):
            return jsonify({
                'error': 'Username, email, and password are required',
                'status': 'error'
            }), 400
        
        # Check if user already exists
        if User.query.filter(User.username == username).first():
            return jsonify({
                'error': 'Username already exists',
                'status': 'error'
            }), 409
            
        if User.query.filter(User.email == email).first():
            return jsonify({
                'error': 'Email already registered',
                'status': 'error'
            }), 409
        
        # Create new user
        user = User(
            username=username,
            email=email,
            first_name=first_name if first_name else None,
            last_name=last_name if last_name else None
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Log in the new user
        login_user(user, remember=True)
        
        return jsonify({
            'success': True,
            'message': 'Account created successfully',
            'user': user.to_dict()
        })
        
    except Exception as e:
        app.logger.error(f"Registration error: {str(e)}")
        db.session.rollback()
        return jsonify({
            'error': 'An error occurred during registration',
            'status': 'error'
        }), 500

@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    """Handle user logout"""
    logout_user()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/user/theme', methods=['POST'])
@login_required
def update_theme():
    """Update user theme preference"""
    try:
        data = request.get_json()
        theme = data.get('theme')
        
        if theme not in ['light', 'dark']:
            return jsonify({
                'error': 'Invalid theme. Must be "light" or "dark"',
                'status': 'error'
            }), 400
        
        current_user.theme_preference = theme
        db.session.commit()
        
        return jsonify({
            'success': True,
            'theme': theme,
            'message': 'Theme updated successfully'
        })
        
    except Exception as e:
        app.logger.error(f"Theme update error: {str(e)}")
        return jsonify({
            'error': 'Failed to update theme',
            'status': 'error'
        }), 500

@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    """Handle chat messages and return AI responses"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'error': 'Invalid request body'
            }), 400
        
        user_message = data.get('message', '').strip()
        mode = data.get('mode', 'chat')
        files = data.get('files', [])
        
        if not user_message and not files:
            return jsonify({
                'error': 'Message or files must be provided'
            }), 400
        
        # Get AI response based on mode and content
        ai_response = chat_service.get_response(user_message, mode, files)
        
        return jsonify({
            'response': ai_response,
            'status': 'success',
            'mode': mode
        })
        
    except Exception as e:
        app.logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            'error': 'An error occurred while processing your message. Please try again.',
            'status': 'error'
        }), 500

@app.route('/api/user', methods=['GET'])
@login_required
def get_user():
    """Get current user info"""
    return jsonify({
        'user': current_user.to_dict(),
        'authenticated': True
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'AI Chat Assistant with Authentication'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
