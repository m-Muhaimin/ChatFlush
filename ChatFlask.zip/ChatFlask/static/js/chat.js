// Modern BeeBot-inspired Chat Application
class ModernChatApp {
    constructor() {
        this.initializeElements();
        this.initializeState();
        this.initializeEventListeners();
        this.initializeUI();
    }

    initializeElements() {
        // Main elements
        this.welcomeScreen = document.getElementById('welcomeScreen');
        this.messagesContainer = document.getElementById('messagesContainer');
        this.messagesContent = document.getElementById('messagesContent');
        this.loadingMessage = document.getElementById('loadingMessage');
        
        // Input elements
        this.chatForm = document.getElementById('chatForm');
        this.messageInput = document.getElementById('messageInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.attachmentBtn = document.getElementById('attachmentBtn');
        this.fileInput = document.getElementById('fileInput');
        
        // Multimodal tools
        this.reasoningBtn = document.getElementById('reasoningBtn');
        this.createImageBtn = document.getElementById('createImageBtn');
        this.deepResearchBtn = document.getElementById('deepResearchBtn');
        
        // Sidebar elements
        this.newChatBtn = document.getElementById('newChatBtn');
        this.chatHistory = document.getElementById('chatHistory');
        
        // Suggestion cards
        this.suggestionCards = document.querySelectorAll('.suggestion-card');
    }

    initializeState() {
        this.isLoading = false;
        this.currentChatId = null;
        this.messageHistory = [];
        this.attachedFiles = [];
        this.activeMode = 'chat'; // 'chat', 'reasoning', 'create-image', 'deep-research'
    }

    initializeEventListeners() {
        // Form submission
        this.chatForm.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Input handling
        this.messageInput.addEventListener('keydown', (e) => this.handleKeyDown(e));
        this.messageInput.addEventListener('input', () => this.handleInputChange());
        
        // File handling
        this.attachmentBtn.addEventListener('click', () => this.fileInput.click());
        this.fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        
        // Multimodal tools
        this.reasoningBtn.addEventListener('click', () => this.setMode('reasoning'));
        this.createImageBtn.addEventListener('click', () => this.setMode('create-image'));
        this.deepResearchBtn.addEventListener('click', () => this.setMode('deep-research'));
        
        // Sidebar actions
        this.newChatBtn.addEventListener('click', () => this.startNewChat());
        
        // Suggestion cards
        this.suggestionCards.forEach(card => {
            card.addEventListener('click', () => {
                const suggestion = card.dataset.suggestion;
                this.sendMessage(suggestion);
            });
        });
        
        // Auto-resize textarea
        this.messageInput.addEventListener('input', () => this.autoResizeTextarea());
    }

    initializeUI() {
        this.updateSendButton();
        this.messageInput.focus();
        this.updateGreeting();
    }

    updateGreeting() {
        const now = new Date();
        const hour = now.getHours();
        let greeting = 'Good Evening!';
        
        if (hour < 12) {
            greeting = 'Good Morning!';
        } else if (hour < 18) {
            greeting = 'Good Afternoon!';
        }
        
        const titleElement = document.querySelector('.welcome-title');
        if (titleElement) {
            titleElement.textContent = greeting;
        }
    }

    handleSubmit(e) {
        e.preventDefault();
        
        if (this.isLoading) return;
        
        const message = this.messageInput.value.trim();
        if (!message && this.attachedFiles.length === 0) return;
        
        this.sendMessage(message);
    }

    handleKeyDown(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            this.handleSubmit(e);
        }
    }

    handleInputChange() {
        this.updateSendButton();
        this.autoResizeTextarea();
    }

    autoResizeTextarea() {
        const textarea = this.messageInput;
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    updateSendButton() {
        const hasText = this.messageInput.value.trim().length > 0;
        const hasFiles = this.attachedFiles.length > 0;
        const isEnabled = (hasText || hasFiles) && !this.isLoading;
        
        this.sendBtn.disabled = !isEnabled;
        
        if (this.isLoading) {
            this.sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        } else {
            this.sendBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
        }
    }

    async sendMessage(message) {
        // Hide welcome screen and show messages
        this.showMessagesView();
        
        // Add user message
        this.addMessage(message, 'user', this.attachedFiles);
        
        // Clear input and files
        this.messageInput.value = '';
        this.attachedFiles = [];
        this.updateSendButton();
        this.autoResizeTextarea();
        
        // Show loading
        this.showLoading();
        
        try {
            // Prepare request data
            const requestData = {
                message: message,
                mode: this.activeMode,
                files: this.attachedFiles.map(file => ({
                    name: file.name,
                    type: file.type,
                    size: file.size,
                    data: file.data
                }))
            };
            
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Add AI response
            this.addMessage(data.response, 'ai');
            
            // Save to chat history
            this.saveChatHistory(message, data.response);
            
        } catch (error) {
            console.error('Error sending message:', error);
            this.showError(error.message || 'Failed to send message. Please try again.');
        } finally {
            this.hideLoading();
            this.messageInput.focus();
        }
    }

    showMessagesView() {
        this.welcomeScreen.style.display = 'none';
        this.messagesContainer.style.display = 'flex';
    }

    addMessage(content, sender, files = []) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        const timestamp = this.formatTimestamp(new Date());
        const avatar = sender === 'user' 
            ? '<i class="fas fa-user"></i>' 
            : '<i class="fas fa-robot"></i>';
        
        let fileContent = '';
        if (files && files.length > 0) {
            fileContent = '<div class="message-files">';
            files.forEach(file => {
                fileContent += `
                    <div class="file-attachment">
                        <i class="fas fa-paperclip"></i>
                        <span>${file.name}</span>
                    </div>
                `;
            });
            fileContent += '</div>';
        }
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                ${avatar}
            </div>
            <div class="message-content">
                <div class="message-bubble">
                    ${fileContent}
                    <div class="message-text">${this.formatMessage(content)}</div>
                </div>
                <div class="message-time">
                    <small class="text-muted">${timestamp}</small>
                </div>
            </div>
        `;
        
        this.messagesContent.appendChild(messageDiv);
        
        // Store in history
        this.messageHistory.push({
            content: content,
            sender: sender,
            timestamp: new Date(),
            files: files
        });
        
        // Animate and scroll
        this.animateMessage(messageDiv);
        this.scrollToBottom();
    }

    formatMessage(content) {
        if (!content) return '';
        
        return content
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\n/g, '<br>');
    }

    formatTimestamp(date) {
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) {
            return 'Just now';
        } else if (diff < 3600000) {
            const minutes = Math.floor(diff / 60000);
            return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        } else {
            return date.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }
    }

    animateMessage(messageElement) {
        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(20px)';
        
        requestAnimationFrame(() => {
            messageElement.style.transition = 'all 0.3s ease-out';
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
        });
    }

    showLoading() {
        this.isLoading = true;
        this.loadingMessage.style.display = 'block';
        this.updateSendButton();
        this.scrollToBottom();
    }

    hideLoading() {
        this.isLoading = false;
        this.loadingMessage.style.display = 'none';
        this.updateSendButton();
    }

    scrollToBottom() {
        setTimeout(() => {
            if (this.messagesContainer.style.display !== 'none') {
                this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
            }
        }, 100);
    }

    handleFileSelect(e) {
        const files = Array.from(e.target.files);
        
        files.forEach(file => {
            if (this.attachedFiles.length < 5) { // Limit to 5 files
                this.processFile(file);
            }
        });
        
        // Clear input
        e.target.value = '';
    }

    async processFile(file) {
        try {
            const fileData = {
                name: file.name,
                type: file.type,
                size: file.size,
                data: null
            };
            
            // For images, convert to base64
            if (file.type.startsWith('image/')) {
                fileData.data = await this.fileToBase64(file);
            }
            
            this.attachedFiles.push(fileData);
            this.updateSendButton();
            this.displayAttachedFile(fileData);
            
        } catch (error) {
            console.error('Error processing file:', error);
            this.showError('Failed to process file. Please try again.');
        }
    }

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    displayAttachedFile(file) {
        // Create file preview in input area
        const preview = document.createElement('div');
        preview.className = 'file-preview';
        preview.innerHTML = `
            <div class="file-icon">
                <i class="fas fa-${this.getFileIcon(file.type)}"></i>
            </div>
            <div class="file-info">
                <div class="file-name">${file.name}</div>
                <div class="file-size">${this.formatFileSize(file.size)}</div>
            </div>
            <button type="button" class="file-remove">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        preview.querySelector('.file-remove').addEventListener('click', () => {
            this.removeAttachedFile(file);
            preview.remove();
        });
        
        this.chatForm.insertBefore(preview, this.chatForm.querySelector('.input-container'));
    }

    removeAttachedFile(file) {
        this.attachedFiles = this.attachedFiles.filter(f => f !== file);
        this.updateSendButton();
    }

    getFileIcon(type) {
        if (type.startsWith('image/')) return 'image';
        if (type === 'application/pdf') return 'file-pdf';
        if (type.includes('text')) return 'file-alt';
        if (type.includes('document')) return 'file-word';
        return 'file';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    setMode(mode) {
        this.activeMode = mode;
        
        // Update tool button states
        document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.remove('active'));
        
        switch (mode) {
            case 'reasoning':
                this.reasoningBtn.classList.add('active');
                this.messageInput.placeholder = 'Ask me to think through a complex problem step by step...';
                break;
            case 'create-image':
                this.createImageBtn.classList.add('active');
                this.messageInput.placeholder = 'Describe the image you want me to create...';
                break;
            case 'deep-research':
                this.deepResearchBtn.classList.add('active');
                this.messageInput.placeholder = 'What topic would you like me to research thoroughly?';
                break;
            default:
                this.activeMode = 'chat';
                this.messageInput.placeholder = 'Initiate a query or send a command to the AI...';
        }
    }

    startNewChat() {
        // Clear current chat
        this.messagesContent.innerHTML = '';
        this.messageHistory = [];
        this.attachedFiles = [];
        this.currentChatId = null;
        
        // Show welcome screen
        this.welcomeScreen.style.display = 'flex';
        this.messagesContainer.style.display = 'none';
        
        // Reset input
        this.messageInput.value = '';
        this.setMode('chat');
        this.updateSendButton();
        this.messageInput.focus();
    }

    saveChatHistory(userMessage, aiResponse) {
        const chatItem = {
            id: Date.now().toString(),
            title: userMessage.substring(0, 50) + (userMessage.length > 50 ? '...' : ''),
            preview: aiResponse.substring(0, 100) + (aiResponse.length > 100 ? '...' : ''),
            timestamp: new Date()
        };
        
        // Add to chat history UI
        const historyItem = document.createElement('div');
        historyItem.className = 'chat-item';
        historyItem.innerHTML = `
            <div class="chat-title">${chatItem.title}</div>
            <div class="chat-preview">${chatItem.preview}</div>
        `;
        
        this.chatHistory.insertBefore(historyItem, this.chatHistory.firstChild);
        
        // Limit to 10 recent chats
        while (this.chatHistory.children.length > 10) {
            this.chatHistory.removeChild(this.chatHistory.lastChild);
        }
    }

    showError(message) {
        // Show error modal
        const errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
        document.getElementById('errorMessage').textContent = message;
        errorModal.show();
        
        // Also add error message to chat if in conversation
        if (this.messagesContainer.style.display !== 'none') {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.innerHTML = `
                <i class="fas fa-exclamation-triangle me-2"></i>
                ${message}
            `;
            
            this.messagesContent.appendChild(errorDiv);
            this.scrollToBottom();
            
            // Remove after 5 seconds
            setTimeout(() => {
                if (errorDiv.parentNode) {
                    errorDiv.remove();
                }
            }, 5000);
        }
    }

    // Public API methods
    clearChat() {
        this.startNewChat();
    }

    getMessageHistory() {
        return this.messageHistory;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chatApp = new ModernChatApp();
    
    // Handle window resize for responsive design
    window.addEventListener('resize', () => {
        if (window.chatApp) {
            window.chatApp.scrollToBottom();
        }
    });
    
    // Handle page visibility changes
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden && window.chatApp) {
            window.chatApp.messageInput.focus();
        }
    });
});

// Additional CSS for file attachments and multimodal tools
const additionalStyles = `
.message-files {
    margin-bottom: 12px;
}

.file-attachment {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255, 255, 255, 0.1);
    padding: 6px 12px;
    border-radius: 12px;
    margin: 2px;
    font-size: 12px;
}

.file-attachment i {
    opacity: 0.7;
}

.tool-btn.active {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.error-message {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
    border-radius: 8px;
    padding: 12px 16px;
    margin: 16px 0;
    text-align: center;
    animation: messageSlideIn 0.3s ease-out;
}
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);