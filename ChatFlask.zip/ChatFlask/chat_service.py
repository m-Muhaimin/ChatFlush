import os
import logging
from openai import OpenAI

class ChatService:
    """Service class for handling AI chat interactions"""
    
    def __init__(self):
        # Check for Deepseek API credentials first
        self.deepseek_api_key = os.environ.get("DEEPSEEK_API_KEY", "sk-1414609620f448b6966346842d3b64db")
        self.deepseek_api_url = os.environ.get("DEEPSEEK_API_URL", "https://api.deepseek.com/v1")
        self.openai_api_key = os.environ.get("OPENAI_API_KEY")
        self.client = None
        
        # Try Deepseek first, then OpenAI as fallback
        if self.deepseek_api_key:
            try:
                self.client = OpenAI(
                    api_key=self.deepseek_api_key,
                    base_url=self.deepseek_api_url
                )
                logging.info("Deepseek client initialized successfully")
            except Exception as e:
                logging.error(f"Failed to initialize Deepseek client: {e}")
        elif self.openai_api_key:
            try:
                self.client = OpenAI(api_key=self.openai_api_key)
                logging.info("OpenAI client initialized successfully")
            except Exception as e:
                logging.error(f"Failed to initialize OpenAI client: {e}")
        else:
            logging.warning("Neither DEEPSEEK_API_KEY nor OPENAI_API_KEY found in environment variables")
    
    def get_response(self, user_message, mode='chat', files=None):
        """Get AI response for user message with multimodal support"""
        
        if files is None:
            files = []
        
        # Try API first (Deepseek or OpenAI)
        if self.client:
            try:
                # Use deepseek-chat model if using Deepseek API, otherwise use gpt-4o
                model = "deepseek-chat" if self.deepseek_api_key else "gpt-4o"
                
                # Prepare system message based on mode
                system_message = self._get_system_message(mode)
                
                # Prepare messages array
                messages = [{"role": "system", "content": system_message}]
                
                # Handle file attachments (images) - for now, describe them as text
                message_text = user_message
                if files:
                    file_descriptions = []
                    for file in files:
                        if file.get('type', '').startswith('image/'):
                            file_descriptions.append(f"[Image attached: {file.get('name', 'Unknown')}]")
                        else:
                            file_descriptions.append(f"[File attached: {file.get('name', 'Unknown')} ({file.get('type', 'Unknown type')})]")
                    
                    if file_descriptions:
                        message_text = f"{user_message}\n\n{' '.join(file_descriptions)}" if user_message else ' '.join(file_descriptions)
                
                messages.append({
                    "role": "user",
                    "content": message_text
                })
                
                response = self.client.chat.completions.create(
                    model=model,
                    messages=messages,
                    max_tokens=1500 if mode in ['reasoning', 'deep-research'] else 1000,
                    temperature=0.3 if mode == 'reasoning' else 0.7,
                    timeout=30
                )
                
                content = response.choices[0].message.content
                return content.strip() if content else "I apologize, but I couldn't generate a response. Please try again."
                
            except Exception as e:
                logging.error(f"API error: {e}")
                # Fall back to mock response
                return self._get_mock_response(user_message, mode)
        
        # Use mock response if no API is available
        return self._get_mock_response(user_message, mode)
    
    def _get_system_message(self, mode):
        """Get system message based on conversation mode"""
        if mode == 'reasoning':
            return """You are a highly analytical AI assistant specialized in step-by-step reasoning. When faced with complex problems or questions:
1. Break down the problem into smaller components
2. Analyze each component systematically
3. Show your thinking process clearly
4. Provide detailed explanations for each step
5. Present a clear conclusion based on your analysis
Be thorough, logical, and demonstrate clear reasoning throughout your response."""
        
        elif mode == 'create-image':
            return """You are an AI assistant that helps users create detailed image descriptions and concepts. When users ask for image creation:
1. Understand their vision and requirements
2. Provide detailed, creative descriptions
3. Suggest artistic styles, colors, and composition
4. Note: I cannot actually generate images, but I can help craft detailed prompts for image generation tools
5. Be creative and detailed in your descriptions
Always clarify that you're providing detailed prompts rather than actual image generation."""
        
        elif mode == 'deep-research':
            return """You are a thorough research assistant that provides comprehensive, well-structured information. When conducting research:
1. Provide detailed, accurate information from multiple perspectives
2. Structure your response with clear sections and headings
3. Include relevant context and background information
4. Mention limitations of the information when applicable
5. Suggest follow-up questions or areas for further exploration
Be comprehensive, accurate, and well-organized in your research responses."""
        
        else:  # Default chat mode
            return "You are a helpful AI assistant. Provide clear, informative, and engaging responses. Be conversational but professional."
    
    def _get_mock_response(self, user_message, mode='chat'):
        """Generate mock AI response when OpenAI API is unavailable"""
        
        # Simple keyword-based responses for demonstration
        message_lower = user_message.lower()
        
        if any(word in message_lower for word in ['hello', 'hi', 'hey', 'greetings']):
            return "Hello! I'm your AI assistant. How can I help you today?"
        
        elif any(word in message_lower for word in ['help', 'assist', 'support']):
            return "I'm here to help! You can ask me questions, request information, or have a conversation. What would you like to know?"
        
        elif any(word in message_lower for word in ['weather', 'temperature', 'forecast']):
            return "I don't have access to real-time weather data, but I'd recommend checking a reliable weather service for current conditions in your area."
        
        elif any(word in message_lower for word in ['time', 'date', 'today']):
            return "I don't have access to real-time information, but you can check your device's clock for the current time and date."
        
        elif any(word in message_lower for word in ['thank', 'thanks', 'appreciate']):
            return "You're welcome! I'm glad I could help. Is there anything else you'd like to know?"
        
        elif any(word in message_lower for word in ['bye', 'goodbye', 'see you']):
            return "Goodbye! Feel free to come back anytime if you have more questions. Have a great day!"
        
        else:
            return f"I understand you're asking about: '{user_message}'. While I don't have access to real-time data or the full OpenAI API right now, I'm still here to help with general questions and conversations. Could you rephrase your question or ask about something else I might be able to assist with?"
